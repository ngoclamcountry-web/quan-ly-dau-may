# Quản lý Kỹ thuật & Vật tư — Xí nghiệp Đầu máy Sài Gòn

Bản chạy thử để đưa lên Netlify, dùng kiểm tra giao diện và luồng nghiệp vụ
trên nhiều máy và nhiều cỡ màn hình khác nhau.

## Đưa lên Netlify

Cách nhanh nhất, không cần tài khoản Git:

1. Vào https://app.netlify.com/drop
2. Kéo nguyên thư mục này thả vào ô giữa trang.
3. Netlify trả về một địa chỉ dạng `https://<tên-ngẫu-nhiên>.netlify.app` — mở
   địa chỉ đó trên bất kỳ máy nào.

Muốn đổi tên miền: vào Site configuration → Change site name.

Cập nhật bản mới: kéo thả lại thư mục lên chính site đó, mục Deploys.

## Thư mục có gì

- `index.html` — toàn bộ phần mềm trong một tệp: giao diện, 32 biểu mẫu kỹ
  thuật, danh mục 2.852 danh điểm vật tư, 98 đầu máy, sổ đăng kiểm, và số dư
  kho chính thức ngày 01/10/2025.
- `netlify.toml` — cấu hình Netlify, không cần sửa.

## Dữ liệu nằm ở đâu

Bản chạy thử **không có máy chủ**. Mọi biên bản, phiếu kỹ thuật và bút toán kho
được lưu trong trình duyệt của chính máy đang dùng:

- Mỗi máy một sổ riêng. Máy này không thấy biên bản của máy kia.
- Hai thẻ cùng mở trên một máy thì thấy thay đổi của nhau ngay.
- Xóa dữ liệu duyệt web, hoặc dùng cửa sổ ẩn danh, là mất sổ.

Danh mục vật tư, danh sách đầu máy, biểu mẫu và số dư kho thì nằm sẵn trong
`index.html` nên máy nào mở cũng có đủ, không phải nhập gì.

Muốn hai máy xem cùng một bộ dữ liệu: vào mục **Danh mục chứng từ** →
**Tải bản sao lưu (.json)** ở máy thứ nhất, rồi **Nạp bản sao lưu** ở máy thứ hai.

## Thử phân quyền

Góc phải trên có nút tài khoản, bấm vào để đổi vai trò. Mỗi chức danh chỉ thấy
phần việc của mình; vai trò **Quản trị hệ thống** thấy toàn bộ để tinh chỉnh.

Vài luồng nên thử trên nhiều máy:

- Tổ trưởng sản xuất lập bộ phiếu kỹ thuật theo bộ phận rồi gửi đi.
- KTV Phòng KT-KCS kiểm tra, Trưởng phòng duyệt hoặc trả lại cả bộ.
- KTV lập phiếu sửa chữa tai nạn, bấm gửi — phiếu hiện ngay ở tài khoản Tổ
  trưởng, Quản đốc và Phó Giám đốc Kỹ thuật, không qua bước duyệt nào.
- Lập biên bản giải thể và xem cột **Tồn kho** ngay cạnh cột số lượng.
- Mở **Lý lịch đầu máy**, chọn một máy bất kỳ.
- Mở **Kho & tồn kho** bằng tài khoản Thủ kho rồi đổi sang Phó Giám đốc Kỹ
  thuật để thấy khác biệt giữa quyền điều chỉnh và quyền chỉ tra cứu.
